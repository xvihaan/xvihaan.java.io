package org.javaro.lecture;
public class MyStore {
	public static void main(String[] args) {
	BookStore testLibrary = new BookStore("도서관리 시스템");
	Book b1 = new Book("<춘향전>"); 
	Book b2 = new Book("<홍길동전>");
	Book b3 = new Book("<심청전>"); 
	Book b4 = new Book("<전쟁과 평화>");
	Book b5 = new Book("<논어>"); 

	
	b1.setAuthor("성춘향");
	b2.setAuthor("홍길동");
	b3.setAuthor("심청전");
	b4.setAuthor("톨스토이");
	b5.setAuthor("공자");
	
	Student stud1 = new Student();
	Student stud2 = new Student();
	Student stud3 = new Student();
	Student stud4 = new Student();
	
	stud1.setName("홍길동");  stud2.setName("성춘향");
	stud3.setName("변학도");  stud4.setName("이몽룡");
	
	testLibrary.addBook(b1);   testLibrary.addBook(b2);
	testLibrary.addBook(b3);   testLibrary.addBook(b4);
	testLibrary.addBook(b5);
	
	testLibrary.addStudents(stud1);  testLibrary.addStudents(stud2);
	testLibrary.addStudents(stud3);  testLibrary.addStudents(stud4);
	
	System.out.println("지산도서관 관리 시스템 생성\n");
	testLibrary.printStatus();
	testLibrary.checkOut(b1,stud1);
	System.out.println("춘향전을 홍길동이 대출");
	testLibrary.checkOut(b3,stud1);
	System.out.println("심청전을 홍길동이 대출");
	testLibrary.printStatus();
	testLibrary.checkIn(b3);
	System.out.println("심청전 반납");
	testLibrary.checkOut(b3, stud3);
	System.out.println("심청전을 변학도가 대출");
	testLibrary.checkOut(b4, stud2);
	System.out.println("전쟁과 평화를 성춘향이 대출");
	testLibrary.checkOut(b5, stud3);
	System.out.println("논어를 변학도가 대출");
	testLibrary.printStatus();
	testLibrary.checkIn(b4);
	System.out.println("전쟁과 평화 반납");
	testLibrary.printStatus();
	}
}
