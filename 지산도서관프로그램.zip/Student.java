package org.javaro.lecture;
public class Student {
	private String name;
	private int maxBooks;
	public Student() {
		this.name = "unknown name";
		this.maxBooks = 5;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMaxBooks() {
		return maxBooks;
	}
	public void setMaxBooks(int maxBooks) {
		this.maxBooks = maxBooks;
	}
	public String toString() {
		return this.getName()+" (최대 "+ this.maxBooks+"권)";
	}
}
	