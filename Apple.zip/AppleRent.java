package org.apple.rent;
import java.util.ArrayList;
public class AppleRent {
	public String name;
	public ArrayList<Apple> apples;
	public ArrayList<Customer> customers;
	public AppleRent(String name) {
		this.name = name;
		apples = new ArrayList<Apple>();
		customers = new ArrayList<Customer>();
	}
	public String getName() {
		return name; }
	public ArrayList<Apple> getApples() {
		return this.apples; }
	public ArrayList<Customer> getCustomers() {
	    return this.customers; }
	public void addApple(Apple apple1) {
		this.apples.add(apple1); }
	public void removeApple(Apple apple1) {
		this.apples.remove(apple1); }
	public void addCustomers(Customer customer) {
		this.customers.add(customer); }
	public void removeCustomer(Customer customer) {
		this.customers.remove(customer); 
}
public boolean rentOut(Apple apple1, Customer p1) {
	int applesOut = this.getApplesForCustomer(p1).size();
	if( (apple1.getCustomer()==null)
		&& (applesOut < p1.getMaxApples()) )
	{
		apple1.setCustomer(p1);
		return true;
	} 
	else {
		return false;
	}
}
public boolean rentIn(Apple apple1) {
	if(apple1.getCustomer()!=null) {
		apple1.setCustomer(null);
		return true;
	} else {
		return false;
	}
}
public ArrayList<Apple> getApplesForCustomer(Customer p1) {
	ArrayList<Apple> result = new ArrayList<Apple>();
	for (Apple aApple : this.getApples()) {
		if ((aApple.getCustomer()!=null)&&(aApple.getCustomer().getName().equals(p1.getName()))) {
			result.add(aApple);
		}
	}
	return result;
}
public ArrayList<Apple> getAvailableApples() {
	ArrayList<Apple> result = new ArrayList<Apple>();
	for (Apple aApple : this.getApples()) {
		if(aApple.getCustomer() ==null) {
			result.add(aApple);
		}
	}
	return result;
}
public ArrayList<Apple> getUnavailableApples() {
	ArrayList<Apple> result = new ArrayList<Apple>();
	for (Apple aApple : this.getApples()) {
		if(aApple.getCustomer() ==null) {
			result.add(aApple);
		}
	}
	return result;
}
public String toString() {
	return this.getName() + "의 애플제품= " +
    this.getApples().size() + "대 제품, 렌탈 고객수: "+
	this.getCustomers().size() + "명";
}
public void printStatus() {
	System.out.println("=================== 애플 렌트샵 현황 ====================\n" + this.toString());
	for (Apple thisApple : this.getApples()) {
		System.out.println(thisApple);
		
	}
	for (Customer p : this.getCustomers()) {
		int count = this.getApplesForCustomer(p).size();
		System.out.println(p + "은/는 " + count + "제품 렌탈 중");
	}
	System.out.println("현재 렌탈이 가능한 제품: " + this.getAvailableApples().size());
	System.out.println("------------------ 애플 렌트샵 현황 종료 ------------------");
  }
}


