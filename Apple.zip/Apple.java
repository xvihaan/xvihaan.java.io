package org.apple.rent;
public class Apple {
    public String product, model;   
    private Customer customer;
    public Apple(String string) 
    {  this.product = string;  this.model = "unknown model"; }
    public String getModel() {
    	return model;
    }
    public void setModel(String model) 
    {  this.model = model; }
    public String getProduct() 
    {  return product; }
    public void setCustomer(Customer customer) 
    {  this.customer = customer; }
    public Customer getCustomer() 
    {  return this.customer; } 
    
    public String toString() { 
    	String available;
    	if (this.getCustomer()==null) { 
    		available = " 렌트 가능";
    	} else {
    		available = " 렌탈 고객: " + this.getCustomer().getName();
    	}
    	return " 제품 = "+this.getProduct()+", 모델 = "+this.getModel()+","+available;
	}
}
