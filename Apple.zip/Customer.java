package org.apple.rent;
public class Customer {
	private String name;
	private int maxApples;
	public Customer() {
		this.name = "unknown name";
		this.maxApples = 6;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMaxApples() {
		return maxApples;
	}
	public void setMaxApples(int maxApples) {
		this.maxApples = maxApples;
	}
	public String toSting() {
		return this.getName()+" (최대"+this.maxApples+" 제품)";
  }
}
