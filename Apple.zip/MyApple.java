package org.apple.rent;
public class MyApple {
	public static void main(String[] args) {
		AppleRent AppleWindow = new AppleRent("애플 렌트샵");
		Apple apple1 = new Apple("iMac"); 
		Apple apple2 = new Apple("MacBook air");
		Apple apple3 = new Apple("MacBook pro");
		Apple apple4 = new Apple("iPad");
		Apple apple5 = new Apple("Apple watch");
		Apple apple6 = new Apple("AirPods Max");
		
		apple1.setModel("24인치");
		apple2.setModel("air");
		apple3.setModel("pro");
		apple4.setModel("9세대");
		apple5.setModel("42mm");
		apple6.setModel("Silver");
		
		Customer cust1 = new Customer();
		Customer cust2 = new Customer();
		// Customer cust3 = new Customer();
		// Customer cust4 = new Customer();
		// Customer cust5 = new Customer();
		// Customer cust6 = new Customer();
		
		cust1.setName("김민혁");  cust2.setName("박재우");
		
		AppleWindow.addApple(apple1);  AppleWindow.addApple(apple2);
		AppleWindow.addApple(apple3);  AppleWindow.addApple(apple4);
		AppleWindow.addApple(apple5);  AppleWindow.addApple(apple6);
		
		AppleWindow.addCustomers(cust1);  AppleWindow.addCustomers(cust2);

		
		System.out.println("▶▶▶▶▶▶▶▶▶▶▶▶▶▶▶ 애플 렌트시스템 생성 ◀◀◀◀◀◀◀◀◀◀◀◀◀◀◀\n");
		AppleWindow.printStatus();
		AppleWindow.rentOut(apple2, cust1);
		System.out.println("Macbook air을 김민혁에게 대출");
		AppleWindow.printStatus();
		AppleWindow.rentIn(apple2);
		System.out.println("Macbook air 렌트반납");
		AppleWindow.rentOut(apple4, cust2);
		System.out.println("iPad pro를 박재우에게 대출");
		AppleWindow.printStatus();
		AppleWindow.rentIn(apple4);
		System.out.println("iPad pro 렌트반납");
		AppleWindow.printStatus();

		
		
	
	}

}