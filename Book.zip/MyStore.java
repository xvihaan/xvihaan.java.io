package org.javaro.lecture;
public class MyStore {
	public static void main(String[] args) {
	BookStore testLibrary = new BookStore("도서관리 시스템");
	Book b1 = new Book("전쟁과 평화"); 
	Book b2 = new Book("인류와 세계");
	b1.setAuthor("톨스토이");
	b2.setAuthor("디킨스");
	Student stud1 = new Student();
	Student stud2 = new Student();
	stud1.setName("홍길동");  stud2.setName("성춘향");
	testLibrary.addBook(b1);   testLibrary.addBook(b2);
	testLibrary.addStudents(stud1);  testLibrary.addStudents(stud2);
	System.out.println("도서관리 시스템 생성");
	testLibrary.printStatus();
	testLibrary.checkOut(b1,stud2);
	testLibrary.printStatus();
	testLibrary.checkIn(b1);
	testLibrary.checkOut(b2, stud1);
	testLibrary.printStatus();
	}
}
