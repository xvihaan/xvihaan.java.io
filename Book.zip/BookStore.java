package org.javaro.lecture;
import java.util.ArrayList;
public class BookStore {
	public String name;
	public ArrayList<Book> books;
	public ArrayList<Student> students;
	public BookStore(String name) {
		this.name = name;
		books = new ArrayList<Book>();
		students = new ArrayList<Student>();
	}
	public String getName() {
		return name; }
	public ArrayList<Book> getBooks() {
		return this.books; }
	public ArrayList<Student> getStudents() {
	    return this.students; }
	public void addBook(Book b1) {
		this.books.add(b1); }
	public void removeBook(Book b1) {
		this.books.remove(b1); }
	public void addStudents(Student student) {
		this.students.add(student); }
	public void removeStudent(Student student) {
		this.students.remove(student); 
}
public boolean checkOut(Book b1, Student p1) {
	int booksOut = this.getBooksForStudent(p1).size();
	if( (b1.getStudent()==null)
		&& (booksOut < p1.getMaxBooks()) )
	{
		b1.setStudent(p1);
		return true;
	} 
	else {
		return false;
	}
}
public boolean checkIn(Book b1) {
	if(b1.getStudent()!=null) {
		b1.setStudent(null);
		return true;
	} else {
		return false;
	}
}
public ArrayList<Book> getBooksForStudent(Student p1) {
	ArrayList<Book> result = new ArrayList<Book>();
	for (Book aBook : this.getBooks()) {
		if ((aBook.getStudent()!=null)&&(aBook.getStudent().getName().equals(p1.getName()))) {
			result.add(aBook);
		}
	}
	return result;
}
public ArrayList<Book> getAvailableBooks() {
	ArrayList<Book> result = new ArrayList<Book>();
	for (Book aBook : this.getBooks()) {
		if(aBook.getStudent() ==null) {
			result.add(aBook);
		}
	}
	return result;
}
public ArrayList<Book> getUnavailableBooks() {
	ArrayList<Book> result = new ArrayList<Book>();
	for (Book aBook : this.getBooks()) {
		if(aBook.getStudent() ==null) {
			result.add(aBook);
		}
	}
	return result;
}
public String toString() {
	return this.getName() + ": " +
    this.getBooks().size() + "권;"+
	this.getStudents().size() + "명.";
}
public void printStatus() {
	System.out.println("도서관리 리포트\n" + this.toString());
	for (Book thisBook : this.getBooks()) {
		System.out.println(thisBook);
		
	}
	for (Student p : this.getStudents()) {
		int count = this.getBooksForStudent(p).size();
		System.out.println(p + "는 " + count + "권 대출");
	}
	System.out.println("대출 가능 책:" + this.getAvailableBooks().size());
	System.out.println("--- 리포트 종료 ---");
  }
}


