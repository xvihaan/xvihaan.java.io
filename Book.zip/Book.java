package org.javaro.lecture;
public class Book {
    public String title, author;   
    private Student student;
    public Book(String string) 
    {  this.title = string;  this.author = "unknown author"; }
    public String getAuthor() {
    	return author;
    }
    public void setAuthor(String author) 
    {  this.author = author; }
    public String getTitle() 
    {  return title; }
    public void setStudent(Student student) 
    {  this.student = student; }
    public Student getStudent() 
    {  return this.student; } 
    
    public String toString() { 
    	String available;
    	if (this.getStudent()==null) { 
    		available = "대출가능";
    	} else {
    		available = "대출됨=" + this.getStudent().getName();
    	}
    	return this.getTitle()+" 저자 "+this.getAuthor()+","+available;
	}
}

